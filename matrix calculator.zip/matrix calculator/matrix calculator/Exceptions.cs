﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Net;
using System.Numerics;
using System.Runtime.ExceptionServices;

class Exceptions
{
    /// <summary>
    /// Ошибка размера матрицы.
    /// </summary>
    public static void RangeException()
    {

        Console.WriteLine("Или размеры заданных матриц не подходят для текущей операции.");
    }

    /// <summary>
    /// Неверные элементы матрицы.
    /// </summary>
    public static void ValuesEror()
    {
        Console.WriteLine("Введенная матрица не соотвествуют данным размерам или " + Environment.NewLine +
            $"значения не вляются вещественными числами от {Program.MinValueS} до {Program.MaxValueS}");
    }
    /// <summary>
    /// Отсутствие обратной матрицы.
    /// </summary>
    public static void NoInverseMatrix()
    {
        Console.WriteLine("Обратной матрицы не существует, так как ее определитель равен 0");
    }

    /// <summary>
    /// Приветсвие.
    /// </summary>
    public static void HelloText()
    {
        Console.WriteLine("Приветсвую в матричном калькуляторе. Чтобы узнать больше напиши help.");
        Console.WriteLine("Краткий список команд:");
        int newLineFlag = 0;
        foreach (var i in Program.Commands)
        {
            if (newLineFlag % 5 == 0)
            {
                Console.WriteLine();
            }
            Console.Write(" {0,6}", i);
            newLineFlag++;

        }
        Console.WriteLine();

        Console.WriteLine("Введите команду");
    }

    /// <summary>
    /// Описание команд и вывода.
    /// </summary>
    public static void Help()
    {
        string text = "Данный калькулятор поддерживает следущие команды:" + Environment.NewLine +
            "Help - описание команд" + Environment.NewLine +
            "det(A) - определитель матрица (1 операнд: матрица)" + Environment.NewLine +
            "T(A) - транспонирование матрицы (1 операнд: матрица )" + Environment.NewLine +
            "S(A) - след матрица (1 операнд: матрица)" + Environment.NewLine +
            "-A - Вычисление матрицы *-1 (1 операнд: матрица)" + Environment.NewLine +
            "A+B - сложение матриц (2 операнда: матрица , матрица)" + Environment.NewLine +
            "A-B - вычитание матриц (2 операнда: матрица , матрица)" + Environment.NewLine +
            "A*B - умножение матрицы на матрицу (2 операнда: матрица, матрица)" + Environment.NewLine +
            "A*k - умножение матрица на число(2 операнда: матрица, матрица)" + Environment.NewLine +
            "Ax=b - Решение СЛАУ методом  Крамера(2 операнда: матрица, матрица)" + Environment.NewLine +
            "A^-1 - вычисление обратной матрицы (1 операнд: матрица)" + Environment.NewLine + Environment.NewLine +

            "Матрицы задаются в файле input.txt, который находится в одной папке с программой" + Environment.NewLine +
            "или вводятся через консоль или генерируются случайным образом." + Environment.NewLine +
           $"Размерность матриц от {Program.MinSize} до {Program.MaxSize}, значения матриц -" +
           $" вещественные числа от {Program.MinValueS} до {Program.MaxValueS}." + Environment.NewLine +
            "Матрица вводится построчно. Элементы в строках разделены пробелами." + Environment.NewLine +
            "Если выбран ввод из файла, то в файле сначала идут размерности матриц (по одной в строку), а затем задаются матрицы." +
            "Для операций S(A), det(A), A^-1 - размерность квадратной матрицы это одно число от {Program.MinValueS} до {Program.MaxValueS}." + Environment.NewLine +
           "Для операций T(A),-A, A+B, A-B - 2 размерности: число строк и столбцов - числа от {Program.MinValueS} до {Program.MaxValueS}." + Environment.NewLine +
           "Для операции A*B - 3 размерности: число строк и столбцовб в м-це А и число столбцов в B- числа от {Program.MinValueS} до {Program.MaxValueS}." + Environment.NewLine +
            "Для операций A*k- сначало вводится число k {Program.MinValueS} до {Program.MaxValueS} pfntv 2 размерности A: число строк и" +
            " столбцовб - числа от {Program.MinValueS} до {Program.MaxValueS}." + Environment.NewLine +
             "Для операции Ax=b - 1 размерности м-цы A - числа от {Program.MinValueS} до {Program.MaxValueS},затем вводится м-ца A, затем столбец b";

        Console.WriteLine(text);

    }

    /// <summary>^
    /// Команда не существует.
    /// </summary>
    public static void NotExistCommand()
    {
        Console.WriteLine("Команда не найдена");
    }

    /// <summary>
    /// Сообщение о завершении или продолжении работы.
    /// </summary>
    public static void EndText()
    {
        Console.WriteLine("Введите следущую команду или нажмите Escape для выхода");
    }

    /// <summary>
    /// Прощание.
    /// </summary>
    public static void ByeText()
    {
        Console.WriteLine("До свидания");
    }


}