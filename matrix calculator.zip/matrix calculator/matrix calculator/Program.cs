﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.Design;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
// Дополнительный функционал: -A, обратная матрица,решение СЛАУ.

class Program
{
    public static Random Rnd = new Random();
    public static int MaxSize = 12,
        MinSize = 1;
    public static double MaxValue = 1e5,
        MinValue = -1e5;
    public static String MaxValueS = "10^5",
        MinValueS = "-10^5";
    public static List<string> Commands = new List<string>
    {"Help", "det(A)", "T(A)", "S(A)", "-A ", "A+B", "A-B", "A*B", "A*k", "A^-1","Ax=b"};

    static bool GetCommand(out string command)
    {
        command = Console.ReadLine().Trim().ToLower();
        foreach (var i in Commands)
        {
            if (i.Trim().ToLower() == command)
            {
                return true;
            }
        }
        Exceptions.NotExistCommand();
        return false;
    }

    /// <summary>
    /// Ввод размерности квадратной марицы.
    /// </summary>
    /// <param name="n">размерность</param>
    /// <returns>Возращает размерность</returns>
    public static int SquareSize()
    {
        Console.Write($"Введите размерность квадратной матрицы (одно число от {Program.MinSize} до {Program.MaxSize}) ");
        int n;
        while (!int.TryParse(Console.ReadLine(), out n) || MinSize > n || n > MaxSize)
        {
            Console.Write("Неверный ввод попробуйте еще раз ");
        }
        return n;
    }

    /// <summary>
    /// Ввод размерности квадратной марицы.
    /// </summary>
    /// <param name="n">размерность</param>
    /// <returns>Возращает False, если данные некорректны</returns>
    public static bool SquareSizeFromFile(out int n)
    {
        n = -1;
        try
        {
            List<string> Lines = File.ReadAllLines("input.txt").ToList<string>();

            if (!int.TryParse(Lines[0].Trim(), out n) || MinSize > n || n > MaxSize)
            {
                Console.WriteLine("Данные в файле некорректны или файл не существует");
                return false;
            }
            return true;
        }
        catch (Exception)
        {
            Console.WriteLine("Данные в файле некорректны или файл не существует");
            return false;
        }
    }

    /// <summary>
    /// Ввод размерностей прямоугольной матрицы.
    /// </summary>
    /// <param name="n">количество строк</param>
    /// <param name="m">количество столбцов</param>
    public static void RectangleSize(out int n, out int m)
    {
        Console.Write($"Введите количество строк матрицы (одно число от {Program.MinSize} до {Program.MaxSize}) ");
        n = 0;
        while (!int.TryParse(Console.ReadLine(), out n) || MinSize > n || n > MaxSize)
        {
            Console.Write("Неверный ввод попробуйте еще раз ");
        }
        Console.Write($"Введите количество столбцов матрицы (одно число от {Program.MinSize} до {Program.MaxSize}) ");
        m = 0;
        while (!int.TryParse(Console.ReadLine(), out m) || MinSize > m || m > MaxSize)
        {
            Console.Write("Неверный ввод попробуйте еще раз ");
        }
    }


    /// <summary>
    /// вод размерностей прямоугольной матрицы из файла.
    /// </summary>
    /// <param name="n">количество строк</param>
    /// <param name="m">количество столбцов</param>
    /// <returns>Возращает False, если данные некорректны</returns>
    public static bool RectangleSizeFromFile(out int n, out int m, int startInd = 0)
    {
        n = -1;
        m = -1;
        try
        {
            List<string> Lines = File.ReadAllLines("input.txt").ToList<string>();

            if (!int.TryParse(Lines[0 + startInd].Trim(), out n) || MinSize > n || n > MaxSize)
            {
                Console.WriteLine("Данные в файле некорректны или файл не существует");
                return false;
            }

            if (!int.TryParse(Lines[1 + startInd].Trim(), out m) || MinSize > m || m > MaxSize)
            {
                Console.WriteLine("Данные в файле некорректны или файл не существует");
                return false;
            }
            return true;
        }
        catch (Exception)
        {
            Console.WriteLine("Данные в файле некорректны или файл не существует");
            return false;
        }
    }

    /// <summary>
    /// Ввод размерностей прямоугольных матриц для умножения.
    /// </summary>
    /// <param name="n">количество строк A</param>
    /// <param name="m">количество столбцов A</param>
    /// <param name="k">количество столбцов B</param>
    public static void RectangleSize(out int n, out int m, out int k)
    {
        Console.Write($"Введите количество строк матрицы A (одно число от {Program.MinSize} до {Program.MaxSize}) ");
        n = 0;
        while (!int.TryParse(Console.ReadLine(), out n) || MinSize > n || n > MaxSize)
        {
            Console.Write("Неверный ввод попробуйте еще раз ");
        }
        Console.Write($"Введите количество столбцов матрицы A =" +
            $" колличеству сток матрицы B (одно число от {Program.MinSize} до {Program.MaxSize}) ");
        m = 0;
        while (!int.TryParse(Console.ReadLine(), out m) || MinSize > m || m > MaxSize)
        {
            Console.Write("Неверный ввод попробуйте еще раз ");
        }
        Console.Write($"Введите количество столбцов матрицы B (одно число от {Program.MinSize} до {Program.MaxSize}) ");
        k = 0;
        while (!int.TryParse(Console.ReadLine(), out k) || MinSize > k || k > MaxSize)
        {
            Console.Write("Неверный ввод попробуйте еще раз ");
        }
    }


    /// <summary>
    /// Ввод размерностей прямоугольных матриц для умножения.
    /// </summary>
    /// <param name="n">количество строк A</param>
    /// <param name="m">количество столбцов A</param>
    /// <param name="k">количество столбцов B</param>
    /// <returns>False, если данные некорректны</returns>
    public static bool RectangleSizeFromFile(out int n, out int m, out int k)
    {
        n = -1;
        m = -1;
        k = -1;
        try
        {
            List<string> Lines = File.ReadAllLines("input.txt").ToList<string>();

            if (!int.TryParse(Lines[0].Trim(), out n) || MinSize > n || n > MaxSize)
            {
                Console.WriteLine("Данные в файле некорректны или файл не существует");
                return false;
            }

            if (!int.TryParse(Lines[1].Trim(), out m) || MinSize > m || m > MaxSize)
            {
                Console.WriteLine("Данные в файле некорректны или файл не существует");
                return false;
            }
            if (!int.TryParse(Lines[2].Trim(), out k) || MinSize > k || k > MaxSize)
            {
                Console.WriteLine("Данные в файле некорректны или файл не существует");
                return false;
            }
            return true;
        }
        catch (Exception)
        {
            Console.WriteLine("Данные в файле некорректны или файл не существует");
            return false;
        }
    }

    /// <summary>
    /// Выбор типа ввода информации.
    /// </summary>
    /// <returns></returns>
    public static int TypeOFInput()
    {
        Console.WriteLine("Выберите тип ввода (введите цифру) через файл(1) через консоль(2) или генерация случайного массива(3) ");
        int typeOfInput;
        while (!int.TryParse(Console.ReadLine(), out typeOfInput) || typeOfInput < 1 || typeOfInput > 3)
        {
            Console.WriteLine("Введено некорректное значение. Повторите ввод");
        }
        return typeOfInput;

    }

    /// <summary>
    /// Вывод числа.
    /// </summary>
    /// <param name="numb">число</param>
    static void Print(double numb)
    {
        Console.WriteLine($"Результат выполнения операции - число {String.Format("{0:f4}", numb)}");
    }

    /// <summary>
    /// Вывод матрицы.
    /// </summary>
    /// <param name="A">Матрица</param>
    static void Print(Matrix A)
    {
        if (!A.Exists)
            return;
        Console.WriteLine($"Результат выполнения операции - матрица {A.Height}x{A.Width} :");
        for (int i = 0; i < A.Height; i++)
        {
            for (int j = 0; j < A.Width; j++)
            {
                Console.Write("{0:f4} ", A.Values[i][j]);
            }
            Console.WriteLine();
        }
    }
    /// <summary>
    /// Чтение матрицы из файла.
    /// </summary>
    /// <param name="n">Количество строк</param>
    /// <param name="m">Количество столбцов</param>
    /// <param name="arr">Массив значний</param>
    /// <returns>Возвращает Fals если, матрца некорректна</returns>
    public static bool ReadMatrixFromFile(int n, int m, out List<List<double>> arr, int startIndex = 0)
    {
        arr = new List<List<double>>();
        try
        {
            List<string> input = new List<string>();
            input = File.ReadAllLines("input.txt").ToList<string>();

            for (int i = startIndex; i < n + startIndex; i++)
            {
                arr.Add(new List<double>());
                List<string> line = input[i].Split(' ', StringSplitOptions.RemoveEmptyEntries).ToList<string>();
                if (line.Count != m)
                {
                    Exceptions.ValuesEror();
                    return false;
                }

                for (int j = 0; j < m; j++)
                {
                    double numb;
                    if (!double.TryParse(line[j], out numb) || numb < MinValue || numb > MaxValue)
                    {
                        Exceptions.ValuesEror();
                        return false;
                    }
                    arr[i - startIndex].Add(numb);
                }
            }
            return true;
        }
        catch (Exception)
        {
            Console.WriteLine("Данные в файле некорректны или файл не существует");
            return false;
        }
    }

    /// <summary>
    /// Чтение матрицы из консоли.
    /// </summary>
    /// <param name="n">Количество строк</param>
    /// <param name="m">Количество столбцов</param>
    /// <param name="arr">Массив значний</param>
    /// <returns>Возвращает Fals если, матрца некорректна</returns>
    public static bool ReadMatrixFromConsole(int n, int m, out List<List<double>> arr)
    {
        Console.WriteLine($"Введите значения матрицы - вещественные числа от {Program.MinValueS} до {Program.MaxValueS}");
        arr = new List<List<double>>();
        for (int i = 0; i < n; i++)
        {
            arr.Add(new List<double>());
            List<string> input = new List<string>();
            input = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries).ToList<string>();
            if (input.Count != m)
            {
                Exceptions.ValuesEror();
                return false;
            }

            for (int j = 0; j < m; j++)
            {
                double numb;
                if (!double.TryParse(input[j], out numb) || numb < MinValue || numb > MaxValue)
                {
                    Exceptions.ValuesEror();
                    return false;
                }
                arr[i].Add(numb);
            }
        }
        return true;
    }

    static bool ReadNumberFormFile(out double x)
    {
        x = -1;
        try
        {
            List<string> Lines = File.ReadAllLines("input.txt").ToList<string>();

            if (!double.TryParse(Lines[0].Trim(), out x) || MinValue > x || x > MaxValue)
            {
                Console.WriteLine("Данные в файле некорректны или файл не существует");
                return false;
            }
            return true;
        }
        catch (Exception)
        {
            Console.WriteLine("Данные в файле некорректны или файл не существует");
            return false;
        }
    }

    /// <summary>
    /// Чтение матрицы
    /// </summary>
    /// <param name="n">Количество строк</param>
    /// <param name="m">Количество столбцов</param>
    /// <param name="typeOfInput">тип ввода</param>
    /// <returns>Матрица</returns>
    static Matrix ReadMatrix(int n, int m, int typeOfInput, int startIndex = 0)
    {
        List<List<double>> arr = new List<List<double>>();
        Matrix Result;
        switch (typeOfInput)
        {
            case 1:
                if (!ReadMatrixFromFile(n, m, out arr, startIndex))
                {
                    Result = new Matrix(1);
                    Result.Exists = false;
                    return Result;
                }
                break;
            case 2:
                if (!ReadMatrixFromConsole(n, m, out arr))
                {
                    Result = new Matrix(1);
                    Result.Exists = false;
                    return Result;
                }
                break;
            case 3:
                Console.WriteLine("Сгенерирована матрица:");
                for (int i = 0; i < n; i++)
                {
                    arr.Add(new List<double>());
                    for (int j = 0; j < m; j++)
                    {
                        arr[i].Add(Rnd.NextDouble() + Rnd.Next((int)(MinValue + 1), (int)MaxValue));
                        Console.Write("{0:f4} ", arr[i][j]);
                    }
                    Console.WriteLine();
                }

                break;
        }
        return new Matrix(n, m, ref arr);
    }

    /// <summary>
    ///  Вычисление детерминанта.
    /// </summary>
    static void Det()
    {
        int tipeOfInput = TypeOFInput();
        int n;
        if (tipeOfInput != 1)
            n = SquareSize();
        else if (!SquareSizeFromFile(out n))
        {
            return;
        }
        Matrix A = ReadMatrix(n, n, tipeOfInput, 1);
        double result;
        Matrix.Det(A, out result);
        if (A.Exists)
            Print(result);
    }

    /// <summary>
    /// Транспонирование матрицы.
    /// </summary>
    static void Trans()
    {
        int n, m;
        int tipeOfInput = TypeOFInput();
        if (tipeOfInput != 1)
            RectangleSize(out n, out m);
        else if (!RectangleSizeFromFile(out n, out m))
        {
            return;
        }
        Matrix A = ReadMatrix(n, m, tipeOfInput, 2);
        if (A.Exists)
            Print(~A);
    }

    /// <summary>
    /// След матрицы.
    /// </summary>
    static void Should()
    {
        int tipeOfInput = TypeOFInput();
        int n;
        if (tipeOfInput != 1)
            n = SquareSize();
        else if (!SquareSizeFromFile(out n))
        {
            return;
        }
        Matrix A = ReadMatrix(n, n, tipeOfInput, 1);
        double result;
        Matrix.Should(A, out result);
        if (A.Exists)
            Print(result);
    }

    /// <summary>
    /// Унарный минус для матрицы.
    /// </summary>
    static void UnaryMInus()
    {
        int n, m;
        int tipeOfInput = TypeOFInput();
        if (tipeOfInput != 1)
            RectangleSize(out n, out m);
        else if (!RectangleSizeFromFile(out n, out m))
        {
            return;
        }
        Matrix A = ReadMatrix(n, m, tipeOfInput, 2);
        if (A.Exists)
            Print(-A);
    }

    /// <summary>
    /// Сложение матриц.
    /// </summary>
    static void Sum()
    {
        int n, m;
        int tipeOfInput = TypeOFInput();
        if (tipeOfInput != 1)
            RectangleSize(out n, out m);
        else if (!RectangleSizeFromFile(out n, out m))
        {
            return;
        }
        Matrix A = ReadMatrix(n, m, tipeOfInput, 2);
        Matrix B = ReadMatrix(n, m, tipeOfInput, n + 2);
        if (A.Exists && B.Exists)
            Print(A + B);
    }

    /// <summary>
    /// Вычитание матриц.
    /// </summary>
    static void Minus()
    {
        int n, m;
        int tipeOfInput = TypeOFInput();
        if (tipeOfInput != 1)
            RectangleSize(out n, out m);
        else if (!RectangleSizeFromFile(out n, out m))
        {
            return;
        }
        Matrix A = ReadMatrix(n, m, tipeOfInput, 2);
        Matrix B = ReadMatrix(n, m, tipeOfInput, n + 2);
        if (A.Exists && B.Exists)
            Print(A - B);
    }

    /// <summary>
    /// Умножение матриц.
    /// </summary>
    static void Composition()
    {
        int n = -1, m = -1, k = -1;
        int typeOfInput = TypeOFInput();
        if (typeOfInput != 1)
            RectangleSize(out n, out m, out k);
        else
        {
            if (!RectangleSizeFromFile(out n, out m, out k))
            {
                return;
            }
        }
        Matrix A = ReadMatrix(n, m, typeOfInput, 3);
        Matrix B = ReadMatrix(m, k, typeOfInput, n + 3);
        if (A.Exists && B.Exists)
            Print(A * B);
    }

    /// <summary>
    /// Умножение матрицы на число.
    /// </summary>
    static void CompositionWithNumber()
    {

        int n, m;
        double numb;
        int tipeOfInput = TypeOFInput();
        if (tipeOfInput != 1)
        {
            if (tipeOfInput == 2)
            {
                Console.WriteLine($"Введите число от {Program.MinValueS} до {Program.MaxValueS}");
                while (!double.TryParse(Console.ReadLine(), out numb) || numb < MinValue || numb > MaxValue)
                {
                    Console.Write("Некорректное число. Введите другое ");
                }
            }
            else
            {
                numb = Rnd.NextDouble() + Rnd.Next((int)MinValue + 1, (int)MaxValue);
                Console.WriteLine($"Сгенерировано число {String.Format("{0:f4}", numb)}");

            }
            RectangleSize(out n, out m);
        }
        else
        {
            if (!ReadNumberFormFile(out numb) || !RectangleSizeFromFile(out n, out m, 1))
            {
                return;
            }
        }
        Matrix A = ReadMatrix(n, m, tipeOfInput, 3);
        if (A.Exists)
            Print(numb * A);
    }

    /// <summary>
    /// Нахождение обратной матрицы.
    /// </summary>
    static void Inverse()
    {
        int tipeOfInput = TypeOFInput();
        int n;
        if (tipeOfInput != 1)
            n = SquareSize();
        else if (!SquareSizeFromFile(out n))
        {
            return;
        }
        Matrix A = ReadMatrix(n, n, tipeOfInput, 1);

        if (A.Exists)
            Print(!A);
    }

    /// <summary>
    /// Решение СЛАУ методом Крамера.
    /// </summary>
    static void Kramer()
    {
        int tipeOfInput = TypeOFInput();
        int n;
        if (tipeOfInput != 1)
            n = SquareSize();
        else if (!SquareSizeFromFile(out n))
        {
            return;
        }
        Matrix A = ReadMatrix(n, n, tipeOfInput, 1);
        Matrix b = ReadMatrix(n, 1, tipeOfInput, n + 1);
        if (!A.Exists || !b.Exists)
            return;
        double detA;
        Matrix.Det(A, out detA);
        bool notNullDet = false;
        List<double> detX = new List<double>();
        for (int i = 0; i < n; i++)
        {
            Matrix matrixForKramer = new Matrix(A);
            for (int j = 0; j < n; j++)
            {
                matrixForKramer.Values[j][i] = b.Values[j][0];
            }
            double detXI;
            Matrix.Det(matrixForKramer, out detXI);
            detX.Add(detXI);
            if (Math.Abs(detXI) > 1e-12)
                notNullDet = true;
        }
        if (Math.Abs(detA) < 1e-12)
        {
            if (notNullDet)
            {
                Console.WriteLine("СЛАУ несовместная.");
            }
            else
            {

                Console.WriteLine("СЛАУ имеет бесконечно много решений.");
            }
        }
        else
        {
            Console.WriteLine("Решение СЛАУ:");
            for (int i = 0; i < n; i++)
            {
                double xValue= detX[i] / detA;
                Console.WriteLine($"x{i + 1} = {string.Format("{0:f4}", xValue)}");
            }
        }
        }
        static void Main()
        {
            Console.WriteLine("{0:f4}", Math.Pow(1e5, 12) * 12);
            Exceptions.HelloText();
            do
            {
                string command;
                if (GetCommand(out command))
                {
                    Console.WriteLine();
                    switch (command)
                    {
                        case "help":
                            Exceptions.Help();
                            break;
                        case "det(a)":
                            Det();
                            break;
                        case "t(a)":
                            Trans();
                            break;
                        case "s(a)":
                            Should();
                            break;
                        case "-a":
                            UnaryMInus();
                            break;
                        case "a+b":
                            Sum();
                            break;
                        case "a-b":
                            Minus();
                            break;
                        case "a*b":
                            Composition();
                            break;
                        case "a*k":
                            CompositionWithNumber();
                            break;
                        case "a^-1":
                            Inverse();
                            break;
                        case "ax=b":
                            Kramer();
                            break;
                    }
                }
                Console.WriteLine();
                Exceptions.EndText();
            } while (Console.ReadKey(true).Key != ConsoleKey.Escape);
            Exceptions.ByeText();
        }
    }

