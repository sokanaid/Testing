﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Runtime.ExceptionServices;
using System.Threading;

class Matrix
{
    // Поля.

    public int Height,
        Width;
    public bool Exists = true;
    public List<List<double>> Values;

    // Конмтрукторы.

    /// <summary>
    /// Создание матрицы. 
    /// </summary>
    /// <param name="n">Высота</param>
    /// <param name="m">Ширина</param>
    /// <param name="arr">Значения</param>
    public Matrix(int n, int m, ref List<List<double>> arr)
    {
        Values = new List<List<double>>();
        for (int i = 0; i < n; i++)
        {
            Values.Add(new List<double>());
            for (int j = 0; j < m; j++)
            {
                Values[i].Add(arr[i][j]);
            }
        }
        Height = n;
        Width = m;
    }

    /// <summary>
    /// Создание копии матрицы.
    /// </summary>
    /// <param name="A">Копируемая матрица</param>
    public Matrix(Matrix A)
    {
        Height = A.Height;
        Width = A.Width;
        Values = new List<List<double>>();
        for(int i=0; i<Height; i++)
        {
            Values.Add(new List<double>());
            for(int j=0; j<Width; j++)
            {
                Values[i].Add(A.Values[i][j]);
            }
        }
    }
    private Matrix(int n, int m, List<List<double>> arr) : this(n, m, ref arr)
    {

    }

    /// <summary>
    /// Создание Квадратной матрицы.
    /// </summary>
    /// <param name="n">Размерность</param>
    /// <param name="arr">Значения</param>
    public Matrix(int n, ref List<List<double>> arr) : this(n, n, arr)
    {
    }

    /// <summary>
    /// Создание Пустой матрицы.
    /// </summary>
    /// <param name="n">Высота</param>
    /// <param name="m">Ширина</param>
    public Matrix(int n, int m) : this(n, m, EmptyArr(n, m))
    {
    }

    /// <summary>
    /// Создание пустой квадратной матрицы. 
    /// </summary>
    /// <param name="n">Размерность</param>
    public Matrix(int n) : this(n, n)
    {
    }

    //Операторы.


    /// <summary>
    /// Сложение матриц.
    /// </summary>
    /// <param name="A">Первая матрица</param>
    /// <param name="B">Вторая матрица</param>
    /// <returns>Сумма матриц</returns>
    public static Matrix operator +(Matrix A, Matrix B)
    {
        Matrix C = new Matrix(A.Height, A.Width, ref A.Values);
        if (A.Height != B.Height || A.Width != B.Width)
        {
            Exceptions.RangeException();
            C.Exists = false;
            return C;
        }

        for (int i = 0; i < A.Height; i++)
        {
            for (int j = 0; j < A.Width; j++)
            {
                C.Values[i][j] += B.Values[i][j];
            }
        }
        return C;

    }

    /// <summary>
    ///  Разность Матриц.
    /// </summary>
    /// <param name="A">Первая Матрца</param>
    /// <param name="B">Вторая Матрица</param>
    /// <returns>Разность матриц</returns>
    public static Matrix operator -(Matrix A, Matrix B) => A + (-B);

    /// <summary>
    /// Унарный минус для матрица
    /// </summary>
    /// <param name="A">Матрица</param>
    /// <returns>-Матрица</returns>
    public static Matrix operator -(Matrix A) => -1 * A;

    /// <summary>
    /// Умножение матрицы на число.
    /// </summary>
    /// <param name="A">матрица</param>
    /// <param name="numb">число</param>
    /// <returns>Произведение</returns>
    public static Matrix operator *(double numb, Matrix A) => A * numb;
    public static Matrix operator *(Matrix A, double numb)

    {
        Matrix C = new Matrix(A);
        for (int i = 0; i < C.Height; i++)
        {
            for (int j = 0; j < C.Width; j++)
            {
                C.Values[i][j] = numb * C.Values[i][j];
            }
        }
        return C;
    }

    /// <summary>
    /// Умножение матриц.
    /// </summary>
    /// <param name="A">Первая матрица</param>
    /// <param name="B">Вторая матрица</param>
    /// <returns>Произведение матриц</returns>
    public static Matrix operator *(Matrix A, Matrix B)
    {
        Matrix C = new Matrix(A.Height, B.Width);
        if (A.Width != B.Height)
        {
            Exceptions.RangeException();
            C.Exists = false;
            return C;
        }

        for (int i = 0; i < C.Height; i++)
        {
            for (int j = 0; j < C.Width; j++)
            {
                for (int k = 0; k < A.Width; k++)
                {
                    C.Values[i][j] += A.Values[i][k] * B.Values[k][j];
                }

            }
        }
        return C;
    }


    /// <summary>
    /// Транспонирование матрицы.
    /// </summary>
    /// <param name="A">Матрица</param>
    /// <returns>Транспонированная матрица</returns>
    public static Matrix operator ~(Matrix A)
    {
        Matrix C = new Matrix(A.Width, A.Height);
        for (int i = 0; i < C.Height; i++)
        {
            for (int j = 0; j < C.Width; j++)
            {
                C.Values[i][j] = A.Values[j][i];
            }
        }
        return C;
    }

    /// <summary>
    /// Нахождение обратной матрицы.
    /// </summary>
    /// <param name="A">Матрица</param>
    /// <returns>Обратная матрица</returns>
    public static Matrix operator !(Matrix A)
    {
        Matrix C = new Matrix(A.Height);
        if (A.Height != A.Width)
        {
            Exceptions.RangeException();
            C.Exists = false;
            return C;

        }
        if (Math.Abs(Det(A)) < 1e-12)
        {
            Exceptions.NoInverseMatrix();
            C.Exists = false;
            return C;
        }
        for (int i = 0; i < C.Height; i++)
        {
            for (int j = 0; j < C.Width; j++)
            {
                C.Values[i][j] = Math.Pow(-1, i + j + 2) * Minor(i, j, A);
            }
        }
        C = ~C;
        C = 1 / Det(A) * C;
        return C;

    }

    // Методы.

    /// <summary>
    /// Получение нулевой матрицы.
    /// </summary>
    /// <param name="n">Высота</param>
    /// <param name="m">Ширина</param>
    /// <returns>Нулевая Матрица</returns>
    private static List<List<double>> EmptyArr(int n, int m)
    {
        List<List<double>> arr = new List<List<double>>();
        for (int i = 0; i < n; i++)
        {
            arr.Add(new List<double>());
            for (int j = 0; j < m; j++)
            {
                arr[i].Add(0);
            }

        }
        return arr;
    }

    /// <summary>
    /// След матрицы.
    /// </summary>
    /// <param name="A"></param>
    /// <param name="ans"></param>
    /// <returns>Возвращает False, если матрица не квадратная</returns>
    public static bool Should(Matrix A, out double ans)
    {
        ans = 0;

        if (A.Width != A.Height)
        {
            Exceptions.RangeException();
            return false;
        }
        for (int i = 0; i < A.Height; i++)
        {
            ans += A.Values[i][i];
        }
        return true;
    }

    /// <summary>
    /// Определитель матрицы.
    /// </summary>
    /// <param name="A"></param>
    /// <param name="ans"></param>
    /// <returns>Возвращает False, если матрица не квадратная</returns>
    public static bool Det(Matrix A, out double ans)
    {
        ans = 0;

        if (A.Width != A.Height)
        {
            Exceptions.RangeException();
            return false;
        }
        ans = Det(A);
        return true;
    }

    /// <summary>
    /// Рекурсивное вычисление определителя через разложение по строке.
    /// </summary>
    /// <param name="A">Матрица</param>
    /// <returns>Значение определителя</returns>
    private static double Det(Matrix A)
    {
        if (A.Height == 1)
            return A.Values[0][0];
        double ans = 0;
        for (int i = 0; i < A.Height; i++)
        {
            ans += Math.Pow(-1, i + 1 + 1) * A.Values[0][i] * Minor(0, i, A);
        }
        return ans;
    }

    /// <summary>
    /// Дополняющий минор Mij. 
    /// </summary>
    /// <param name="i">строка</param>
    /// <param name="j">столбец</param>
    /// <param name="A">матрица</param>
    /// <returns>значение минора</returns>
    private static double Minor(int i, int j, Matrix A)
    {
        Matrix minor = new Matrix(A.Height - 1, A.Width - 1);
        int afterI = 0;
        for (int k = 0; k < A.Height; k++)
        {
            if (k == i)
            {
                afterI = 1;
                continue;
            }
            int afterJ = 0;
            for (int g = 0; g < A.Width; g++)
            {
                if (g == j)
                {
                    afterJ = 1;
                    continue;
                }

                minor.Values[k - afterI][g - afterJ] = A.Values[k][g];

            }
        }

        return Det(minor);
    }

}