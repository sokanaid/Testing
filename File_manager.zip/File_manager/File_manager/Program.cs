﻿using System;
using System.IO;
using System.Reflection;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using Microsoft.VisualBasic.FileIO;
/// <summary>
/// В Help.txt прописаны все команды.
/// Дополнительный функционал - просмотр информации о дисках, папках, функция очистки консоли.
/// </summary>
class Program
{
    static void MergeFiles(string path)
    {
        try
        {
            if (!Directory.Exists(path))
            {
                Console.WriteLine("unable to get information");
                return;
            }
            Console.Write("Write count of files ");
            int countoffiles;
            while (!int.TryParse(Console.ReadLine(), out countoffiles) || countoffiles <= 1)
            {
                Console.Write("Incorrect number. Try again ");
            }
            string filePath = "";
            string firstFilePath = "";
            Console.Write($"Write name of out file with expansion ");
            firstFilePath = Path.Combine(path,Console.ReadLine().Trim());
            
            while (File.Exists(filePath))
            {
                Console.Write("Incorrect name of file. Try again ");
                firstFilePath = Path.Combine(path, Console.ReadLine().Trim());
            }
            for (int i = 0; i < countoffiles; i++)
            {
                Console.Write($"Write full path of file {i + 1} ");
                filePath = Console.ReadLine().Trim();

                while (!File.Exists(filePath))
                {
                    Console.Write("Incorrect path of file. Try again ");
                    filePath = Console.ReadLine().Trim();
                }
                if (i == 0)
                {
                    firstFilePath =filePath;
                    File.WriteAllLines(firstFilePath, File.ReadAllLines(filePath, Encoding.UTF8), Encoding.UTF8);
                    
                }
                else
                {

                    File.AppendAllLines(firstFilePath, File.ReadAllLines(filePath,Encoding.UTF8),Encoding.UTF8);
                   
                }
            }
            Console.WriteLine($"Files was merged in {Path.GetFileName(firstFilePath)}:");
            foreach (var i in File.ReadAllLines(firstFilePath,Encoding.UTF8))
            {
                Console.WriteLine(i);
            }
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
    }

    /// <summary>
    /// Создать файл
    /// </summary>
    /// <param name="path">Путь к папке</param>
    /// <param name="code">Истина если пользователь вводит кодировку сам</param>
    static void CreateFile(string path, bool code = false)
    {
        try
        {
            if (!Directory.Exists(path))
            {
                Console.WriteLine("unable to get information");
                return;
            }
            int encod = 1;
            if (code)
            {
                encod = GetEncoding();
            }
            // Выбор имени файла

            Console.Write("Write name of file with expansion ");

            string fileName = Console.ReadLine();
            while (File.Exists(Path.Combine(path, fileName)))
            {
                Console.Write("Name is incorrect.Try again ");
                fileName = Console.ReadLine();
            }
            string filePath = Path.Combine(path, fileName);
            Console.WriteLine("Write a line of text");
            string Text = Console.ReadLine();
            switch (encod - 1)
            {

                case 0:
                    File.WriteAllText(filePath, Text, Encoding.UTF8);
                    Console.WriteLine($"File {fileName} is created");
                    return;
                case 1:
                    File.WriteAllText(filePath, Text, Encoding.Unicode);
                    Console.WriteLine($"File {fileName} is created");
                    return;
                case 2:
                    File.WriteAllText(filePath, Text, Encoding.UTF32);
                    Console.WriteLine($"File {fileName} is created");
                    return;
                case 3:
                    File.WriteAllText(filePath, Text, Encoding.ASCII);
                    Console.WriteLine($"File {fileName} is created");
                    return;

            }
            //Console.WriteLine($"File {fileName} is created");
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
        return;
    }

    /// <summary>
    /// Выбор файла
    /// </summary>
    /// <param name="Names"> Список файлов</param>
    /// <returns>Имя выбранного файла</returns>
    static string ChooseFile(ref List<string> Names)
    {
        try
        {

            if (Names.Count <= 0) return "";
            Console.Write("Write number or name of file ");
            int number;
            string str = Console.ReadLine().Trim();
            while (!(int.TryParse(str, out number) && number >= 1 && number <= Names.Count) && !Names.Any(s => Path.GetFileName(s) == str))
            {
                Console.Write("Incorrect number or name of file. Write again ");
                str = Console.ReadLine().Trim();
            }

            if (int.TryParse(str, out number) && number >= 1 && number <= Names.Count)
            {
                return Names[number - 1];
            }
            else
            {
                return Names.Find(s => Path.GetFileName(s) == str);
            }
        }
        catch
        {
            return "";
        }
    }

    /// <summary>
    /// Перемещает файл в выбранную пользователем папку.
    /// </summary>
    /// <param name="path">Путь к текущей папке</param>
    static void MoveFile(string path)
    {
        try
        {
            if (!Directory.Exists(path))
            {
                Console.WriteLine("unable to get information");
                return;
            }
            List<string> filesName = GetFiles(path);
            string filePath = ChooseFile(ref filesName);
            Console.Write("Write full path directory where you want copy file ");

            string newPath = Console.ReadLine().Trim();
            while (!Directory.Exists(newPath))
            {
                Console.Write("Incorrect path. Write again ");
                newPath = Console.ReadLine().Trim();
            }
            File.Move(filePath, Path.Combine(newPath, Path.GetFileName(filePath)));
            Console.WriteLine($"File {Path.GetFileName(filePath)} move to {newPath}");
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
    }

    /// <summary>
    /// Копирует файл в текущей папке.
    /// </summary>
    /// <param name="path">Путь к текущей папке</param>
    static void FileCopy(string path)
    {
        try
        {
            if (!Directory.Exists(path))
            {
                Console.WriteLine("unable to get information");
                return;
            }
            List<string> filesName = GetFiles(path);

            string filePath = ChooseFile(ref filesName);

            int i = -1;
            // Выбор имени копии.
            string newFilePath = Path.Combine(Path.GetDirectoryName(filePath), Path.GetFileNameWithoutExtension(filePath)
                + i + Path.GetExtension(filePath));
            while (File.Exists(newFilePath))
            {
                i--;
                newFilePath = Path.Combine(Path.GetDirectoryName(filePath), Path.GetFileNameWithoutExtension(filePath)
                    + i + Path.GetExtension(filePath));

            }

            File.Copy(filePath, newFilePath);
            Console.WriteLine($"file {Path.GetFileName(newFilePath)} is copy of {Path.GetFileName(filePath)}");
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
    }
    /// <summary>
    /// Удаляет выбранный файл.
    /// </summary>
    /// <param name="path">Путь к текщей папке</param>
    static void FileDelete(string path)
    {
        try
        {
            if (!Directory.Exists(path))
            {
                Console.WriteLine("unable to get information");
                return;
            }
            List<string> filesName = GetFiles(path);
            Console.Write("Write number or name of file ");
            string filePath = ChooseFile(ref filesName);

            File.Delete(filePath);
            Console.WriteLine($"file {Path.GetFileName(filePath)} is deleted");
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
    }
    /// <summary>
    /// Выбор колмровки.
    /// </summary>
    /// <returns>Номер вбранной кодировки</returns>
    static int GetEncoding()
    {
        try
        {
            List<string> encodingName = new List<string>() { "UTF-8", "Unicode", "UTF-32", "ASCII" };
            for (int i = 0; i < encodingName.Count; i++)
            {
                Console.WriteLine($"    {i + 1}. {encodingName[i]}");
            }
            Console.WriteLine("Write number or neme of encoding");
            int number;
            string str = Console.ReadLine().Trim();
            while (!(int.TryParse(str, out number) && number >= 1 && number <= encodingName.Count) && !encodingName.Any(s => s == str))
            {
                Console.Write("Incorrect number or name of encoding. Write again ");
                str = Console.ReadLine().Trim();
            }

            if (!(int.TryParse(str, out number) && number >= 1 && number <= encodingName.Count))
            {
                number = encodingName.IndexOf(str);
            }
            Console.WriteLine($"{encodingName[number - 1]} is chosen encoding");
            return number;
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
            return -1;
        }


    }

    /// <summary>
    /// Вывод содержимого файла на консоль.
    /// </summary>
    /// <param name="path">Путь к текущему катологу</param>
    /// <param name="code">Истина если пользователь сам указывает кодировку</param>
    static void OpenFile(string path, bool code = false)
    {
        try
        {
            if (!Directory.Exists(path))
            {
                Console.WriteLine("unable to get information");
                return;
            }
            int encod = 1;
            if (code)
            {
                encod = GetEncoding();
            }
            List<string> filesName = GetFiles(path);
            Console.Write("Write number or name of file ");
            string filePath = ChooseFile(ref filesName);

            List<string> Text;
            switch (encod - 1)
            {

                case 0:
                    Text = File.ReadAllLines(filePath, Encoding.UTF8).ToList<string>();
                    foreach (var i in Text)
                    {
                        Console.WriteLine(i);
                    }
                    return;
                case 1:
                    Text = File.ReadAllLines(filePath, Encoding.Unicode).ToList<string>();
                    foreach (var i in Text)
                    {
                        Console.WriteLine(i);
                    }
                    return;
                case 2:
                    Text = File.ReadAllLines(filePath, Encoding.UTF32).ToList<string>();
                    foreach (var i in Text)
                    {
                        Console.WriteLine(i);
                    }
                    return;
                case 3:
                    Text = File.ReadAllLines(filePath, Encoding.ASCII).ToList<string>();
                    foreach (var i in Text)
                    {
                        Console.WriteLine(i);
                    }
                    return;

            }

        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
        return;
    }
    /// <summary>
    /// Список вложенных файлов.
    /// </summary>
    /// <param name="path">Ссылка на текущий католог</param>
    /// <returns>Список имен вложенных файлов.</returns>
    static List<string> GetFiles(string path)
    {
        List<string> filesName = new List<string>();
        try
        {
            
            if (!CurrentDirectory(path))
            {
                return filesName;
            }
            filesName = Directory.GetFiles(path).ToList<string>();
            Console.WriteLine($"In directory {filesName.Count} files");
            for (int i = 0; i < filesName.Count; i++)
            {
                Console.WriteLine($"    {i + 1}. {Path.GetFileName(filesName[i])}");
            }
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
            filesName.Clear();
        }
        return filesName;

    }

    /// <summary>
    /// Переход во вложенную папку.
    /// </summary>
    /// <param name="path">Путь к текущей папке</param>
    static void LevelUp(ref string path)
    {
        try
        {
            List<string> directoriesName = GetDirectoty(path);
            if (directoriesName.Count == 0) return;
            Console.Write("Write number or name of nested directory ");
            string str = Console.ReadLine();
            int number;
            while (!(int.TryParse(str, out number) && number >= 1 && number <= directoriesName.Count)
                && !directoriesName.Any(s => Path.GetFileName(s) == str))
            {
                Console.Write("Incorrect number or name of nested directory ");
                str = Console.ReadLine().Trim();
            }

            if (int.TryParse(str, out number) && number >= 1 && number <= directoriesName.Count)
            {
                path = directoriesName[number - 1];
            }
            else
            {
                path = directoriesName.Find(s => Path.GetFileName(s) == str);
            }
            Console.WriteLine($"{Path.GetFileName(path)} is current derictory");
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
    }

    /// <summary>
    /// Переход к родительской папке.
    /// </summary>
    /// <param name="path">Путь к текущей папке</param>
    static void LevelDown(ref string path)
    {
        try
        {
            if (Directory.Exists(Path.GetDirectoryName(path)))
            {
                path = Path.GetDirectoryName(path);
                string name = Path.GetFileName(path) != string.Empty ? Path.GetFileName(path) : path;
                Console.WriteLine($@"{name} is current directory");
            }
            else
            {
                Console.WriteLine("unable to get information");
            }
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
    }

    /// <summary>
    /// Выбор директории в качестве текущей.
    /// </summary>
    /// <param name="path">путь к текущему катологу</param>
    static void ChooseDirectory(ref string path)
    {

        try
        {
            Console.Write("Full path of directory is ");
            string newPath = Console.ReadLine().Trim();
            while (!Directory.Exists(newPath))
            {
                Console.WriteLine("unable to get information");
                Console.Write("Full path of directory is ");
                newPath = Console.ReadLine().Trim();
            }
            path = newPath;
            Console.WriteLine($"{Path.GetFileName(path)} is current derictory");
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
        }
    }

    /// <summary>
    /// Информация о каталоге и список вложенных каталогов.
    /// </summary>
    /// <param name="path">путь к каталогу</param>
    /// <returns>список имен вложенных каталогов</returns>
    static List<string> GetDirectoty(string path)

    {
        List<string> DirectoriesName = new List<string>();
        if (!CurrentDirectory(path)) return DirectoriesName;
        try
        {
            DirectoriesName = Directory.GetDirectories(path).ToList<string>();
            Console.WriteLine($"{   DirectoriesName.Count()} nested directories:");
            for (int i = 0; i < DirectoriesName.Count(); i++)
            {
                //DirectoriesName[i] = Path.GetFileName(DirectoriesName[i]);
                Console.WriteLine($"        {i + 1}. {Path.GetFileName(DirectoriesName[i])}");
            }

        }
        catch (Exception)
        {
            DirectoriesName.Clear();
            Console.WriteLine("unable to get information");
        }
        return DirectoriesName;
    }

    /// <summary>
    /// Информация о текущей папке.
    /// </summary>
    /// <param name="path">Путь к текущей папке</param>
    /// <returns>Возвращает ложь, если папка не существует или информация о ней недоступна</returns>
    static bool CurrentDirectory(string path)
    {
        try
        {
            DirectoryInfo directory = new DirectoryInfo(path);
            Console.WriteLine($"directory {directory.Name}  :");
            Console.WriteLine($"Full path: {Path.GetFullPath(directory.FullName)}");

        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
            return false;
        }
        return true;
    }
    /// <summary>
    /// Чтение команды из консоли.
    /// </summary>
    /// <returns>Команда</returns>
    static string ReadCommand()
    {
        string str;
        string[] commands = { "/help", "/close", "/rootdisksinfo", "/clean", "/chooserootdisk","/choosedirectory",
            "/directoryinfo","/currentdirectory","/levelup","/leveldown", "/files","/openfile","/openfileencod",
            "/deletefile","/copyfile","/movefile","/createfileencod","/createfile","/mergefiles"};

        str = Console.ReadLine().Trim().ToLower();
        // Проверка есть ли команда среди возможных.
        // Регистр и ведущие пробельные символы не учитываются.
        while (!commands.Any(s => s == str))
        {
            Console.WriteLine("Сommand does not exist.");
            str = Console.ReadLine().Trim().ToLower();


        }
        return str;
    }
    /// <summary>
    /// Информация о корневых дисках.
    /// </summary>
    /// <returns>Список имен дисков</returns>
    static List<string> GetRootDisks()
    {
        List<string> driversName = new List<string>();

        DriveInfo[] allDrives = DriveInfo.GetDrives();
        try
        {
            foreach (var i in allDrives)
            {
                // Имя диска.
                Console.WriteLine($"{driversName.Count + 1}. Disk {i.Name}");
                driversName.Add(i.Name.ToString());
                // Тип диска.
                Console.WriteLine($"    Type : {i.DriveType}");
                if (i.IsReady)
                {
                    // Объем диска. 
                    Console.WriteLine($"    Size : {i.TotalSize} bytes");
                    // Колличество свободного места на диске.
                    Console.WriteLine($"    Free space : {i.TotalFreeSpace} bytes");
                }
            }
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
            driversName.Clear();
        }
        return driversName;
    }


    /// <summary>
    /// Выбор одного из корневых дисков в качестве текущего репозитория.
    /// </summary>
    /// <param name="driversName">Список корневых дисков</param>
    /// <param name="path">Путь к текущему репозиторию</param>
    static void ChooseRootDisk(List<string> driversName, ref string path)
    {
        if (driversName.Count == 0) return;
        Console.Write("Write number or name of disk ");
        string str = Console.ReadLine().Trim();
        int number;

        try
        {
            // Ввод номера диска или его имени.
            while (!(int.TryParse(str, out number) && number >= 1 && number <= driversName.Count) && !driversName.Any(s => s == str))
            {
                Console.Write("Incorrect number or name of disk. Write again ");
                str = Console.ReadLine().Trim();
            }

            if (int.TryParse(str, out number) && number >= 1 && number <= driversName.Count)
            {
                path = driversName[number - 1];
            }
            else path = str;
        }
        catch (Exception)
        {
            Console.WriteLine("unable to get information");
            return;
        }

        Console.WriteLine($"Disk {path} is current directory");

        return;
    }

    /// <summary>
    /// Список доступных команд.
    /// </summary>
    static void Help()
    {

        foreach (var i in File.ReadAllLines("Help.txt"))
        {
            Console.WriteLine(i);
        }
    }
    static void Main(string[] args)
    {
        Help();
        string directoryPath = "";
        // Ввод команды.
        string command = ReadCommand();
        // Выполнение команд до команды close.
        while (command != "/close")
        {

            //Console.WriteLine(directoryPath);
            switch (command)
            {
                case "/help":
                    Help();
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;

                case "/rootdisksinfo":
                    GetRootDisks();
                    Console.WriteLine();
                    command = ReadCommand();

                    continue;
                case "/chooserootdisk":
                    ChooseRootDisk(GetRootDisks(), ref directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/clean":
                    Console.Clear();
                    Help();
                    command = ReadCommand();
                    continue;
                case "/choosedirectory":
                    ChooseDirectory(ref directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/directoryinfo":
                    GetDirectoty(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/currentdirectory":
                    CurrentDirectory(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/levelup":
                    LevelUp(ref directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/leveldown":
                    LevelDown(ref directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/files":
                    GetFiles(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/openfile":
                    OpenFile(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/openfileencod":
                    OpenFile(directoryPath, true);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/deletefile":
                    FileDelete(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/copyfile":
                    FileCopy(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/movefile":
                    MoveFile(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/createfile":
                    CreateFile(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/createfileencod":
                    CreateFile(directoryPath, true);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
                case "/mergefiles":
                    MergeFiles(directoryPath);
                    Console.WriteLine();
                    command = ReadCommand();
                    continue;
            }
            command = ReadCommand();
        }
    }
}
